import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Trash2, CheckCircle, AlertTriangle } from "lucide-react";

export default function TrashAppDemo() {
  const [pickupScheduled, setPickupScheduled] = useState(false);

  return (
    <div className="p-6 max-w-md mx-auto text-center bg-gray-100 min-h-screen flex flex-col justify-center">
      <h1 className="text-2xl font-bold mb-4">Trash Management App - Demo</h1>
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center space-x-4">
            <MapPin size={24} className="text-green-500" />
            <span className="text-lg font-medium">Location: New York, NY</span>
          </div>
          <div className="mt-4 flex items-center justify-center space-x-4">
            <Trash2 size={24} className="text-red-500" />
            <span className="text-lg font-medium">Next Pickup: Friday, 10 AM</span>
          </div>
          <Button
            className="mt-6 w-full"
            onClick={() => setPickupScheduled(true)}
            disabled={pickupScheduled}
          >
            {pickupScheduled ? "Pickup Scheduled" : "Schedule Trash Pickup"}
          </Button>
          {pickupScheduled && (
            <div className="mt-3 flex items-center justify-center space-x-2 text-green-600">
              <CheckCircle size={20} />
              <span className="font-medium">Pickup scheduled successfully!</span>
            </div>
          )}
          <Button className="mt-4 w-full bg-yellow-500 hover:bg-yellow-600">
            <AlertTriangle size={18} className="mr-2" /> Report Illegal Dumping
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}